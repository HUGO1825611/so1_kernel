#![no_std]
#![no_main]

mod vga_buffer;

use core::panic::PanicInfo;

#[unsafe(no_mangle)]
pub extern "C" fn _start() -> ! {
    println!("Hello World! - So1_Kernel UMG");
    println!("Ahora con println! propio, listo para depurar el resto del kernel.");
    
    // Prueba de formateo
    println!("{} + {} = {}", 2, 2, 2 + 2);

    loop {}
}

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}
